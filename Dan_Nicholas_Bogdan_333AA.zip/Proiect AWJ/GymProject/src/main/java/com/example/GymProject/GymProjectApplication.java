package com.example.GymProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(GymProjectApplication.class, args);
	}

}
